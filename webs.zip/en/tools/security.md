# Tool Security <Badge type="warning" text="Important" />

Security mechanisms and permission control for tools.

## Risk Levels {#risk-levels}

| Level | Icon | Description | Example |
|:------|:----:|:------------|:--------|
| **Safe** | 🟢 | Read-only, no side effects | Get time, query info |
| **Medium** | 🟡 | Limited side effects | Send messages |
| **Higher** | 🟠 | Significant actions | Group admin, file ops |
| **Dangerous** | 🔴 | System access | Shell commands |

## Permission Control {#permissions}

### User Levels {#user-levels}

| Level | Description | Default Tools |
|:------|:------------|:--------------|
| **Master** | Bot owner | All tools |
| **Admin** | Group admin | Admin tools |
| **Member** | Regular user | Basic tools |

### Configuration {#config}

```yaml
tools:
  # Global blacklist
  blacklist:
    - shell_execute
    - dangerous_tool
  
  # Permission override
  permissions:
    send_private_message:
      requireMaster: true
```

## Preset-Level Control {#preset-control}

Each preset can define tool whitelist/blacklist:

```yaml
presets:
  - name: safe-mode
    tools:
      whitelist:
        - basic
        - search
      blacklist:
        - admin
        - shell
```

## Category Control {#category-control}

Enable/disable entire tool categories:

```yaml
builtinTools:
  enabledCategories:
    - basic
    - user
    - search
  disabledCategories:
    - shell
    - admin
```

## Dangerous Tool Warning {#dangerous-warning}

::: danger Shell Category
The `shell` category can execute system commands. Only enable in trusted environments!

```yaml
# NOT recommended for production
builtinTools:
  enabledCategories:
    - shell  # ⚠️ Security risk
```
:::

## Best Practices {#best-practices}

| Practice | Description |
|:---------|:------------|
| **Least Privilege** | Only enable needed tools |
| **Audit Logs** | Monitor tool usage via `#工具日志` |
| **Test First** | Test tools before enabling |
| **Regular Review** | Periodically review permissions |

## Audit & Monitoring {#audit}

View tool call logs:

```txt
#工具日志
```

Enable debug mode for detailed logs:

```txt
#ai调试开启
```

## Next Steps {#next}

- [Built-in Tools](./builtin) - Tool reference
- [Configuration](/en/config/) - Full config options
