# About ChatAI Plugin <Badge type="info" text="Info" />

Information about ChatAI Plugin.

## Overview {#overview}

ChatAI Plugin is a powerful AI chat plugin for Yunzai-Bot, featuring:

- 🤖 **Multi-Model Support** - OpenAI, Claude, Gemini, DeepSeek
- 🔧 **MCP Tool Calling** - 60+ built-in tools
- 🧠 **Long-term Memory** - Vector database memory system
- 🎨 **Web Admin Panel** - Modern management interface
- 🔒 **Permission Control** - Granular access control

## Features {#features}

### AI Capabilities

| Feature | Description |
|:--------|:------------|
| Multi-turn Conversation | Context-aware dialogue |
| Tool Calling | AI can use tools to perform actions |
| Image Recognition | Analyze and describe images |
| Voice Support | TTS and voice recognition |
| Long-term Memory | Remember user preferences |

### Management

| Feature | Description |
|:--------|:------------|
| Web Panel | Visual configuration interface |
| Multi-Channel | Load balancing and failover |
| Group Management | Per-group settings |
| Permission Control | User/group level permissions |

## Architecture {#architecture}

```
┌─────────────────────────────────────┐
│           Application Layer          │
│        (Yunzai Plugin Apps)          │
├─────────────────────────────────────┤
│            Service Layer             │
│    (Chat, Memory, Tools, Web)        │
├─────────────────────────────────────┤
│             Core Layer               │
│   (Adapters, MCP, Storage, Utils)    │
└─────────────────────────────────────┘
```

## Technology Stack {#tech-stack}

| Component | Technology |
|:----------|:-----------|
| Runtime | Node.js 18+ |
| Bot Framework | Yunzai-Bot V3 |
| Database | SQLite (better-sqlite3) |
| Web Framework | Express + Next.js |
| AI Protocol | MCP (Model Context Protocol) |

## License {#license}

MIT License - Free for personal and commercial use.

## Contributing {#contributing}

Contributions welcome! See [GitHub](https://github.com/XxxXTeam/chatai-plugin) for:
- Bug reports
- Feature requests
- Pull requests

## Links {#links}

- [GitHub Repository](https://github.com/XxxXTeam/chatai-plugin)
- [Documentation](/)
- [Changelog](/en/changelog)

## Credits {#credits}

Built with ❤️ by the XxxXTeam.

Special thanks to:
- Yunzai-Bot community
- OpenAI, Anthropic, Google for AI APIs
- MCP protocol contributors
