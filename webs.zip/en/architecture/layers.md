# Layered Architecture <Badge type="info" text="Design" />

Understanding the three-layer architecture design.

## Overview {#overview}

```
┌─────────────────────────────────────┐
│      Application Layer (apps/)       │
│   Message handling, command routing  │
├─────────────────────────────────────┤
│      Service Layer (services/)       │
│   Business logic, API services       │
├─────────────────────────────────────┤
│        Core Layer (core/, mcp/)      │
│   Adapters, protocols, storage       │
└─────────────────────────────────────┘
```

## Application Layer {#application}

**Location:** `apps/`

Handles Yunzai-Bot message events and command routing.

| Module | Responsibility |
|:-------|:---------------|
| `chat.js` | Main chat handler |
| `Commands.js` | Command processing |
| `Management.js` | Admin commands |
| `ChatListener.js` | Event listener |

```javascript
// apps/chat.js
export class Chat extends plugin {
  constructor() {
    super({
      name: 'ChatAI',
      event: 'message'
    })
  }

  async accept(e) {
    // Route to service layer
    await chatService.processMessage(e)
  }
}
```

## Service Layer {#service}

**Location:** `src/services/`

Contains business logic and API services.

| Service | Responsibility |
|:--------|:---------------|
| `ChatService` | Conversation management |
| `SkillsAgent` | Tool orchestration |
| `ContextService` | Context management |
| `MemoryService` | Long-term memory |
| `WebServer` | REST API |

```javascript
// services/llm/ChatService.js
class ChatService {
  async sendMessage(options) {
    // Build context
    const context = await this.buildContext(options)
    
    // Call LLM
    const response = await this.llmClient.send(context)
    
    // Handle tool calls
    if (response.toolCalls) {
      return await this.handleToolCalls(response)
    }
    
    return response
  }
}
```

## Core Layer {#core}

**Location:** `src/core/`, `src/mcp/`

Infrastructure and protocol implementations.

| Module | Responsibility |
|:-------|:---------------|
| `adapters/` | LLM client adapters |
| `McpManager` | Tool management |
| `McpClient` | MCP protocol |
| `BuiltinMcpServer` | Built-in tools |
| `cache/` | Caching layer |

```javascript
// core/adapters/AbstractClient.js
class AbstractClient {
  async sendMessage(messages, options) {
    // Abstract method
  }
  
  parseToolCalls(response) {
    // Parse tool calls from response
  }
}
```

## Layer Dependencies {#dependencies}

```mermaid
graph TD
    A[Application Layer] --> B[Service Layer]
    B --> C[Core Layer]
    
    A -.-> C
```

**Rules:**
- Upper layers depend on lower layers
- Lower layers never depend on upper layers
- Cross-layer calls should go through interfaces

## Benefits {#benefits}

| Benefit | Description |
|:--------|:------------|
| **Separation** | Clear responsibility boundaries |
| **Testability** | Layers can be tested independently |
| **Flexibility** | Easy to replace implementations |
| **Maintainability** | Changes isolated to specific layers |

## Next Steps {#next}

- [Data Flow](./data-flow) - Request processing
- [MCP System](./mcp) - Tool protocol
