// https://vitepress.dev/guide/custom-theme
import { h, onMounted, watch, nextTick } from 'vue'
import type { Theme } from 'vitepress'
import { useRoute } from 'vitepress'
import DefaultTheme from 'vitepress/theme'
import mediumZoom from 'medium-zoom'
import './style.css'
import VisitorStats from './VisitorStats.vue'
import CodeBlockEnhancer from './CodeBlockEnhancer.vue'
import MermaidEnhancer from './MermaidEnhancer.vue'

export default {
  extends: DefaultTheme,
  Layout: () => {
    return h(DefaultTheme.Layout, null, {
      'doc-after': () => [h(CodeBlockEnhancer), h(MermaidEnhancer)]
    })
  },
  enhanceApp({ app, router, siteData }) {
    app.component('VisitorStats', VisitorStats)
  },
  setup() {
    const route = useRoute()
    const initZoom = () => {
      mediumZoom('.main img', { background: 'var(--vp-c-bg)' })
    }
    onMounted(() => initZoom())
    watch(() => route.path, () => nextTick(() => initZoom()))
  }
} satisfies Theme
