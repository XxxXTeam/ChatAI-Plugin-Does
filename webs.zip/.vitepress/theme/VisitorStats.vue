<template>
  <div style="display: flex; justify-content: center; margin-top: 2rem;">
    <span style="color: #888; font-size: 13px;">📊 访问统计</span>
  </div>
</template>
