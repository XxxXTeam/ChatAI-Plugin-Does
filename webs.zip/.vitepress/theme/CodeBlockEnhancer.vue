<script setup>
import { onMounted, nextTick, watch } from 'vue'
import { useRoute } from 'vitepress'

const route = useRoute()

const enhanceCodeBlocks = () => {
  nextTick(() => {
    const codeBlocks = document.querySelectorAll('.vp-doc div[class*="language-"]')
    
    codeBlocks.forEach((block) => {
      // 如果已经增强过，跳过
      if (block.querySelector('.code-toolbar')) return
      
      // 创建工具栏容器
      const toolbar = document.createElement('div')
      toolbar.className = 'code-toolbar'
      
      // 创建收起按钮
      const collapseBtn = document.createElement('button')
      collapseBtn.className = 'code-btn code-collapse-btn'
      collapseBtn.title = '收起/展开'
      collapseBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>`
      
      // 创建复制按钮
      const copyBtn = document.createElement('button')
      copyBtn.className = 'code-btn code-copy-btn'
      copyBtn.title = '复制代码'
      copyBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`
      
      // 获取代码区域
      const pre = block.querySelector('pre')
      const code = block.querySelector('code')
      if (!pre || !code) return
      
      let isCollapsed = false
      
      // 收起功能
      collapseBtn.addEventListener('click', () => {
        isCollapsed = !isCollapsed
        if (isCollapsed) {
          pre.style.maxHeight = '0'
          pre.style.overflow = 'hidden'
          pre.style.paddingTop = '0'
          pre.style.paddingBottom = '0'
          block.classList.add('collapsed')
          collapseBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>`
        } else {
          pre.style.maxHeight = ''
          pre.style.overflow = ''
          pre.style.paddingTop = ''
          pre.style.paddingBottom = ''
          block.classList.remove('collapsed')
          collapseBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>`
        }
      })
      
      // 复制功能
      copyBtn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(code.textContent || '')
          copyBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>`
          copyBtn.classList.add('copied')
          setTimeout(() => {
            copyBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`
            copyBtn.classList.remove('copied')
          }, 2000)
        } catch (e) {
          console.error('复制失败', e)
        }
      })
      
      toolbar.appendChild(collapseBtn)
      toolbar.appendChild(copyBtn)
      block.appendChild(toolbar)
      
      // 隐藏原有的复制按钮
      const originalCopy = block.querySelector('button.copy')
      if (originalCopy) {
        originalCopy.style.display = 'none'
      }
    })
  })
}

onMounted(() => {
  enhanceCodeBlocks()
})

watch(() => route.path, () => {
  setTimeout(enhanceCodeBlocks, 100)
})
</script>

<template>
  <ClientOnly>
    <div class="code-block-enhancer"></div>
  </ClientOnly>
</template>

<style>
.code-block-enhancer {
  display: none;
}

/* 工具栏容器 */
.vp-doc div[class*='language-'] .code-toolbar {
  position: absolute;
  top: 0.55rem;
  right: 0.75rem;
  z-index: 10;
  display: flex;
  align-items: center;
  gap: 4px;
}

/* 按钮基础样式 */
.vp-doc div[class*='language-'] .code-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  color: rgba(255, 255, 255, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
}

.vp-doc div[class*='language-'] .code-btn:hover {
  color: rgba(255, 255, 255, 0.9);
  background: rgba(255, 255, 255, 0.1);
}

.vp-doc div[class*='language-'] .code-btn.copied {
  color: #28ca42;
}

/* 代码区域过渡动画 */
.vp-doc div[class*='language-'] pre {
  transition: max-height 0.3s ease, padding 0.3s ease;
}

.vp-doc div[class*='language-'].collapsed pre {
  border-top: none;
}
</style>
